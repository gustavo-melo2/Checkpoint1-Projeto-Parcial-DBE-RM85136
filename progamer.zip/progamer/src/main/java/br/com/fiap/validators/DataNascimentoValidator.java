package br.com.fiap.validators;

import java.util.Date;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.FacesValidator;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

@FacesValidator("DataNascimentoValidator")
public class DataNascimentoValidator implements Validator{

    
    @Override
    public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {
    	Date dataAtual = new Date(System.currentTimeMillis());
        if(((Date) value).after(dataAtual)){
            FacesMessage msg = new FacesMessage("A data inserida não pode ser maior que a data atual.", "Invalid Date format.");
            msg.setSeverity(FacesMessage.SEVERITY_ERROR);
            throw new ValidatorException(msg);
        }

    }

}
